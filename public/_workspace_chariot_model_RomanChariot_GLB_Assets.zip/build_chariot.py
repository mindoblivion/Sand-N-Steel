#!/usr/bin/env python3
"""
Build game-ready Roman racing chariot GLB assets.

Build space:  X = right, Y = forward, Z = up.
Exported as Y-up (glTF standard); forward points down -Z.

Outputs:
  chariot_model/RomanChariot.glb            -> assembled chariot (drop-in)
  chariot_model/RomanChariot_WheelKit.glb   -> 4 swappable wheel variants
"""
import numpy as np
import trimesh
from trimesh.creation import cylinder, box, torus, cone, icosphere, extrude_polygon
from trimesh.transformations import rotation_matrix, translation_matrix
from trimesh.visual.material import PBRMaterial
from shapely.geometry import Polygon

# ----------------------------------------------------------------------------
# Materials (PBR, no textures needed)
# ----------------------------------------------------------------------------
MATS = {
    "Wood":     ([126, 78, 42],   0.0, 0.72),
    "DarkWood": ([92, 56, 30],    0.0, 0.82),
    "Iron":     ([104, 106, 112], 1.0, 0.45),
    "Bronze":   ([198, 150, 66],  1.0, 0.30),
    "Steel":    ([158, 160, 168], 1.0, 0.28),
    "Leather":  ([74, 46, 30],    0.0, 0.90),
}

def material(name):
    rgb, met, rough = MATS[name]
    return PBRMaterial(name=name, baseColorFactor=list(rgb) + [255],
                       metallicFactor=met, roughnessFactor=rough)

def apply_mat(mesh, name):
    mesh.visual = trimesh.visual.TextureVisuals(material=material(name))
    return mesh

# ----------------------------------------------------------------------------
# Transform helpers
# ----------------------------------------------------------------------------
def Rx(a): return rotation_matrix(a, [1, 0, 0])
def Ry(a): return rotation_matrix(a, [0, 1, 0])
def Rz(a): return rotation_matrix(a, [0, 0, 1])

def cyl_between(p1, p2, r, sections=10):
    p1 = np.asarray(p1, float); p2 = np.asarray(p2, float)
    v = p2 - p1; h = float(np.linalg.norm(v))
    c = cylinder(radius=r, height=max(h, 1e-6), sections=sections)
    if h > 1e-9:
        c.apply_transform(trimesh.geometry.align_vectors([0, 0, 1], v / h))
    c.apply_translation((p1 + p2) / 2.0)
    return c

def arc_tube(center, radius, a0, a1, tube_r, n=12, plane="YZ", sections=8):
    center = np.asarray(center, float)
    pts = []
    for i in range(n + 1):
        a = a0 + (a1 - a0) * i / n
        if plane == "YZ":
            p = np.array([0.0, radius * np.cos(a), radius * np.sin(a)])
        else:  # XZ
            p = np.array([radius * np.cos(a), 0.0, radius * np.sin(a)])
        pts.append(p + center)
    return [cyl_between(pts[i], pts[i + 1], tube_r, sections) for i in range(n)]

def merge(meshes):
    return trimesh.util.concatenate(meshes) if len(meshes) > 1 else meshes[0]

def blade_seg(p1, p2, thick, width):
    """A flat blade segment from p1->p2: thin along X, `width` across, `len` long."""
    p1 = np.asarray(p1, float); p2 = np.asarray(p2, float)
    v = p2 - p1; L = float(np.linalg.norm(v))
    if L < 1e-9:
        return None
    b = box(extents=[thick, width, L])
    b.apply_translation([0, 0, L / 2])
    b.apply_transform(trimesh.geometry.align_vectors([0, 0, 1], v / L))
    b.apply_translation(p1)
    return b

# ----------------------------------------------------------------------------
# Wheel builder (local frame: axle axis = X, wheel plane = Y-Z)
# ----------------------------------------------------------------------------
def build_wheel(R=0.65, rim_tube=0.035, width=0.10, n_spokes=8, spoke_r=0.018,
                hub_r=0.075, rim_mat="Wood", spoke_mat="Wood", hub_mat="Bronze",
                metal_band=False, spikes=0, blades=0):
    parts = {}
    def add(mat, mesh): parts.setdefault(mat, []).append(mesh)

    rim = torus(major_radius=R, minor_radius=rim_tube,
                major_segments=44, minor_segments=12)
    rim.apply_transform(Ry(np.pi / 2))
    add(rim_mat, rim)

    if metal_band:
        band = torus(major_radius=R, minor_radius=rim_tube * 1.5,
                     major_segments=44, minor_segments=12)
        band.apply_transform(Ry(np.pi / 2))
        add("Iron", band)

    for i in range(n_spokes):
        a = 2 * np.pi * i / n_spokes
        d = np.array([0.0, np.cos(a), np.sin(a)])
        add(spoke_mat, cyl_between(d * (hub_r * 0.6), d * (R - rim_tube * 0.4),
                                   spoke_r, 8))

    hub = cylinder(radius=hub_r, height=width, sections=20)
    hub.apply_transform(Ry(np.pi / 2))
    add(hub_mat, hub)

    for s in (-1, 1):
        cap = cylinder(radius=hub_r * 0.62, height=0.02, sections=16)
        cap.apply_transform(Ry(np.pi / 2))
        cap.apply_translation([s * (width / 2 + 0.008), 0, 0])
        add("Bronze", cap)

    for i in range(spikes):
        a = 2 * np.pi * i / spikes
        d = np.array([0.0, np.cos(a), np.sin(a)])
        spk = cone(radius=0.028, height=0.13, sections=10)
        spk.apply_transform(trimesh.geometry.align_vectors([0, 0, 1], d))
        spk.apply_translation(d * (R + rim_tube * 0.4))
        add("Iron", spk)

    for i in range(blades):
        a = 2 * np.pi * i / blades
        nseg = 5
        pts = []
        for k in range(nseg + 1):
            f = k / nseg
            ang = a + f * 0.55                       # sweep -> curved scythe
            rr = (hub_r + 0.05) + f * ((R + 0.30) - (hub_r + 0.05))
            pts.append(np.array([0.0, rr * np.cos(ang), rr * np.sin(ang)]))
        for k in range(nseg):
            w = 0.12 * (1.0 - 0.55 * (k / nseg))     # taper toward the tip
            seg = blade_seg(pts[k], pts[k + 1], 0.022, w)
            if seg is not None:
                add("Steel", seg)
        dirv = pts[-1] - pts[-2]
        tipcone = cone(radius=0.05, height=0.16, sections=4)
        tipcone.apply_transform(trimesh.geometry.align_vectors([0, 0, 1], dirv))
        tipcone.apply_translation(pts[-1])
        add("Steel", tipcone)

    return {m: merge(ms) for m, ms in parts.items()}

# ----------------------------------------------------------------------------
# Car body (curved horseshoe tub, open at the back)
# ----------------------------------------------------------------------------
def build_car_body():
    Ro, Ri = 0.46, 0.41
    a0, a1 = -np.radians(148), np.radians(148)
    parts = {}
    def arc(r, t0, t1, n=44):
        return [(r * np.sin(t), r * np.cos(t)) for t in np.linspace(t0, t1, n)]

    floor = extrude_polygon(Polygon(arc(Ro, a0, a1)), 0.06)
    floor.apply_translation([0, 0, 0.70])
    parts.setdefault("Wood", []).append(floor)

    wall = extrude_polygon(Polygon(arc(Ro, a0, a1) + arc(Ri, a1, a0)), 0.50)
    wall.apply_translation([0, 0, 0.70])
    parts.setdefault("Wood", []).append(wall)

    rail_pts = [np.array([x, y, 1.20]) for (x, y) in arc(0.435, a0, a1)]
    for i in range(len(rail_pts) - 1):
        parts.setdefault("Bronze", []).append(
            cyl_between(rail_pts[i], rail_pts[i + 1], 0.022, 8))

    ch = box(extents=[0.52, 0.62, 0.10])
    ch.apply_translation([0, -0.02, 0.655])
    parts.setdefault("DarkWood", []).append(ch)

    for i in range(15):
        t = a0 + (a1 - a0) * i / 14
        p = np.array([Ro * np.sin(t), Ro * np.cos(t), 1.18])
        st = icosphere(radius=0.022, subdivisions=1)
        st.apply_translation(p)
        parts.setdefault("Bronze", []).append(st)

    emb = cylinder(radius=0.10, height=0.02, sections=20)
    emb.apply_transform(Rx(np.pi / 2))
    emb.apply_translation([0, Ro + 0.01, 0.95])
    parts.setdefault("Bronze", []).append(emb)

    for t in (a0, a1):
        p = np.array([Ro * np.sin(t), Ro * np.cos(t), 0.95])
        lb = box(extents=[0.06, 0.06, 0.50])
        lb.apply_translation(p)
        parts.setdefault("Leather", []).append(lb)

    return {m: merge(ms) for m, ms in parts.items()}

# ----------------------------------------------------------------------------
# Assembled chariot
# ----------------------------------------------------------------------------
def build_chariot():
    scene = trimesh.Scene()
    parts = []  # (node, parent, material, mesh)

    axle = cylinder(radius=0.045, height=1.50, sections=16)
    axle.apply_transform(Ry(np.pi / 2)); axle.apply_translation([0, 0, 0.65])
    parts.append(("Axle", "Chariot", "DarkWood", axle))
    for s in (-1, 1):
        cap = cylinder(radius=0.065, height=0.05, sections=16)
        cap.apply_transform(Ry(np.pi / 2)); cap.apply_translation([s * 0.74, 0, 0.65])
        parts.append((f"Axle_Cap_{'L' if s<0 else 'R'}", "Chariot", "Bronze", cap))

    for mat, mesh in build_car_body().items():
        parts.append((f"CarBody_{mat}", "Chariot", mat, mesh))

    p0 = np.array([0, 0.30, 0.72]); p1 = np.array([0, 2.10, 0.98])
    parts.append(("DraughtPole", "Chariot", "Wood", cyl_between(p0, p1, 0.05, 12)))
    for f in (0.25, 0.5, 0.75):
        c = p0 + (p1 - p0) * f
        band = cylinder(radius=0.058, height=0.05, sections=14)
        band.apply_transform(trimesh.geometry.align_vectors([0, 0, 1], (p1 - p0)))
        band.apply_translation(c)
        parts.append((f"Pole_Band_{int(f*100)}", "Chariot", "Bronze", band))

    yoke = cylinder(radius=0.045, height=1.30, sections=14)
    yoke.apply_transform(Ry(np.pi / 2)); yoke.apply_translation([0, 2.02, 0.98])
    parts.append(("Yoke", "Chariot", "Wood", yoke))
    for s in (-1, 1):
        peg = cylinder(radius=0.03, height=0.22, sections=10)
        peg.apply_translation([s * 0.5, 2.02, 1.08])
        parts.append((f"Yoke_Peg_{'L' if s<0 else 'R'}", "Chariot", "Bronze", peg))

    for s in (-1, 1):
        segs = arc_tube(center=[s * 0.50, 0.0, 1.05], radius=0.24,
                        a0=0.0, a1=np.pi, tube_r=0.030, n=14, plane="YZ")
        parts.append((f"Handle_{'L' if s<0 else 'R'}", "Chariot", "DarkWood", merge(segs)))
        grip = cyl_between([s * 0.50, -0.15, 1.29], [s * 0.50, 0.15, 1.29], 0.036, 10)
        parts.append((f"Handle_Grip_{'L' if s<0 else 'R'}", "Chariot", "Bronze", grip))

    fb = box(extents=[0.46, 0.26, 0.05]); fb.apply_translation([0, -0.44, 0.62])
    parts.append(("Footboard", "Chariot", "DarkWood", fb))

    for s, side in ((-1, "L"), (1, "R")):
        for mat, mesh in build_wheel().items():
            m = mesh.copy(); m.apply_translation([s * 0.70, 0, 0.65])
            parts.append((f"Wheel_{side}_{mat}", f"Wheel_{side}", mat, m))

    for grp in ["Chariot", "Wheel_L", "Wheel_R"]:
        scene.graph.update(frame_to=grp, frame_from=None, matrix=np.eye(4))
    for name, parent, mat, mesh in parts:
        scene.add_geometry(apply_mat(mesh, mat), node_name=name,
                           geom_name=name + "_geom", parent_node_name=parent)

    scene.apply_transform(Rx(-np.pi / 2))
    return scene

# ----------------------------------------------------------------------------
# Wheel upgrade kit (4 swappable variants in a row)
# ----------------------------------------------------------------------------
WHEEL_VARIANTS = [
    ("Standard",   dict(rim_mat="Wood", spoke_mat="Wood", hub_mat="Bronze")),
    ("Reinforced", dict(rim_mat="Wood", spoke_mat="Leather", hub_mat="Bronze",
                        metal_band=True, spoke_r=0.024, hub_r=0.085)),
    ("Spiked",     dict(rim_mat="Wood", spoke_mat="Leather", hub_mat="Bronze",
                        metal_band=True, spoke_r=0.024, hub_r=0.085, spikes=12)),
    ("Bladed",     dict(rim_mat="Wood", spoke_mat="Leather", hub_mat="Bronze",
                        metal_band=True, spoke_r=0.024, hub_r=0.085, blades=4)),
]

def build_wheelkit(spacing=2.5):
    scene = trimesh.Scene()
    n = len(WHEEL_VARIANTS)
    for i, (vname, kw) in enumerate(WHEEL_VARIANTS):
        node = f"Wheel_{vname}"
        scene.graph.update(frame_to=node, frame_from=None, matrix=np.eye(4))
        for mat, mesh in build_wheel(**kw).items():
            m = mesh.copy()
            m.apply_transform(Rz(np.pi / 2))
            m.apply_translation([(i - (n - 1) / 2.0) * spacing, 0, 0.75])
            scene.add_geometry(apply_mat(m, mat), node_name=f"{node}_{mat}",
                               geom_name=f"{node}_{mat}_geom", parent_node_name=node)
    scene.apply_transform(Rx(-np.pi / 2))
    return scene

# ----------------------------------------------------------------------------
if __name__ == "__main__":
    ch = build_chariot()
    ch.export("chariot_model/RomanChariot.glb", include_normals=True)
    print("RomanChariot.glb        nodes:", len(ch.graph.nodes),
          "geoms:", len(ch.geometry),
          "bounds:", np.round(ch.bounds, 3).tolist())

    wk = build_wheelkit()
    wk.export("chariot_model/RomanChariot_WheelKit.glb", include_normals=True)
    print("RomanChariot_WheelKit.glb nodes:", len(wk.graph.nodes),
          "geoms:", len(wk.geometry),
          "bounds:", np.round(wk.bounds, 3).tolist())
