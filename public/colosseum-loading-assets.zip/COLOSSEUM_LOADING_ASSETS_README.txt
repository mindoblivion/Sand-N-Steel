Sand & Steel — Colosseum loading artwork

Copy these two files into the repository's public/ directory, replacing the existing files:
  colosseum_loading.webp -> public/colosseum_loading.webp
  colosseum_loading.png  -> public/colosseum_loading.png

Both are 1536 x 864 RGB images. The WebP is the recovered clean source; the PNG is a lossless PNG conversion of that source. The artwork includes the SAND & STEEL title and gladiators, but no baked-in loading label or progress bar. Keep the game's live progress UI as a separate overlay.

SHA-256:
  colosseum_loading.webp  bf7d31df887b4894f99de529cf0a44db40a4d46ac312ba0d8386ef9f480a0f58
  colosseum_loading.png   7a0de025426f22f3305b40aa9e4e313bc6c410eb495e2a51fa0ded2948fa0e56
