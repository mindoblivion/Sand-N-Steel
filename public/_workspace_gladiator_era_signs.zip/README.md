# Gladiator Era — Hanging Cut-Out Shop Signs

A set of ten game-ready 3D signage models for an ancient Roman / gladiator-era city. The defining idea is simple: **the cut-out emblem *is* the sign.** There is no board and no painted panel — each sign is a single extruded metal silhouette that carries the emblem, the building's name and a hanging ring in one solid piece, suspended by a chain from a wrought-iron bracket. The icon, the lettering and the ring are all the same sheet of metal, so it reads exactly like a real pierced-and-cast shop sign swinging over a doorway.

## What you get

Every sign is delivered in two interchangeable forms so it will drop straight into whichever engine or pipeline you use. The primary asset is a self-contained **.glb** (binary glTF) file with embedded PBR materials — the format Unity, Unreal, Godot, Blender and most web viewers import with no extra steps. Alongside it you get a classic **.obj** with its **.mtl** material library for older pipelines or manual material setup. Because the sign is a genuine 3D cut-out, there is no texture map to keep in sync: the colour comes from physically-based metal materials, so the gold, silver, brass and iron surfaces behave correctly under any lighting.

The models are built to a clean, modular node structure so you can pull them apart. Each sign scene is composed of named parts — **`sign`** (the cut-out itself: emblem + name + ring), `post`, `post_base`, `post_cap`, `arm`, `brace`, `scroll`, and `chain_0 … chain_n`. That means you can hide the whole bracket (`post`, `arm`, `brace`, `scroll`, `post_base`, `post_cap`, `chain_*`) to leave just the floating cut-out and mount it flat against a wall, or detach the `sign` and re-use the emblem as a standalone prop, a hanging medallion or an inventory icon without touching any geometry.

Units are metres, the model is Y-up with its base resting on the origin (y = 0), and the sign faces +Z, so you can drop it onto any ground plane and it will stand correctly. The bracket stands about 2.7 m tall, the cut-out sign is about 1.55 m tall and 5 cm thick, and the whole assembly is roughly 1.3 m wide — which reads well at typical first- and third-person player scale. Scale uniformly if your project uses a different unit convention.

## The material palette

Each sign is finished in one of four physically-based metals (metalness 1.0) with tuned roughness, mounted on dark-iron bracket hardware so the metal always pops:

| Metal | Finish |
|---|---|
| **Gold** | Warm, bright, fairly mirror-like (roughness 0.26) |
| **Silver** | Cool, near-mirror, the shiniest of the set (roughness 0.20) |
| **Brass** | Golden but softer and more work-worn (roughness 0.34) |
| **Iron** | Cool grey, matte, forged-looking (roughness 0.46) |

Because the metals are true PBR metals, they need an environment/reflection map to look their best — the included viewer already sets one up (see *Viewing the models* below), and the same applies in-engine: give the metal materials an HDRI or reflection probe and they will gleam properly.

## The ten signs

| Building | Latin subtitle | Metal | Cut-out emblem + name |
|---|---|---|---|
| Grand Colosseum | Colosseum Magnum | Gold | Tiered amphitheatre crowned with a laurel wreath |
| Gladiator Barracks | Castra Gladiatorum | Iron | Gladiator helmet over crossed spears |
| Arena Medical House | Domus Medica | Silver | Winged serpent staff (caduceus) in a laurel wreath |
| City Tavern | Taberna Urbana | Brass | Two clinking tankards with foam and a spark |
| Veteran Gladiator Hall | Aula Veteranorum | Gold | Crossed swords on a laurel wreath with a medallion |
| Gladiator Academy | Academia Gladiatoria | Brass | Sealed scroll with a quill |
| Smithing Forge | Fabrica Ferri | Iron | Hammer striking a molten rod on the anvil, with sparks |
| General Store | Mercatus | Brass | Goods sack spilling coins, with an amphora and basket |
| Records Library | Bibliotheca | Gold | Open book with a scroll and quill |
| Training Hall | Palaestra | Silver | Shield with crossed practice swords and a laurel |

## How the cut-out signs are made

Each emblem starts life as a hand-drawn black-and-white silhouette (a *mask*). The building's name is rendered in the Cinzel typeface and composited beneath the emblem, a hanging ring is added above, and thin connecting stems join the three into one continuous silhouette. That mask is then traced into vector contours — including interior holes, so a tankard keeps its handle gap, a wreath keeps its ring, and the letters of the name keep their counters — and extruded into a single watertight solid with a small chamfered bevel. The finished mesh is centred, scaled to a consistent height and given the sign's metal PBR material, then hung by a chain of torus links from an iron bracket. The result is one clean mesh per sign (about 4,500–6,000 triangles), light enough to instance freely but detailed enough to read clearly up close. The whole pipeline lives in `emblems3d.py` (silhouettes, name-mask compositing and extrusion) and `generate_signs.py` (bracket assembly and export).

## Folder layout

The `signs` folder holds one sub-folder per building, each containing the `.glb` and the `.obj` plus `material.mtl`, with a top-level `manifest.json` listing every sign's id, title, Latin subtitle, metal and file paths. The `viewer` folder contains a browser gallery (`index.html`) and a single-sign product-shot page (`single.html`). The `previews` folder holds a rendered 3/4-view image of every sign, a contact-sheet `montage.png`, and `cutout_masks.png` (the flat cut-out silhouettes). The `assets` folder holds the Cinzel fonts. The Python files at the root — `emblems3d.py`, `generate_signs.py`, `make_montage.py` and `proto_mask.py` — are the generator that produced everything.

## Using the models

In Unity, drag the `.glb` into your Assets folder; the importer will bring in the mesh and its materials, and you can enable the standard shader (set a reflection probe or skybox so the metal gleams). In Unreal, import the `.glb` directly through the Content Browser. In Godot 4, drop the `.glb` in and it becomes a scene you can instance. In Blender, use File ▸ Import ▸ glTF 2.0. For any tool that prefers OBJ, import the `.obj` and keep the `.mtl` in the same folder.

## Customising and regenerating

Everything is generated from a single editable list. Open `generate_signs.py`, edit the `SIGNS` list (title, Latin subtitle, `metal`, `icon` and the display `lines`), then run `python3 generate_signs.py` to rebuild all assets. The available metals are defined in the `METALS` dictionary at the top of the same file, and the bracket dimensions live in `build_scene`. New emblems can be added as silhouette functions in `emblems3d.py`. This makes it quick to add more storefronts — an armourer, a stable, a temple — in exactly the same visual language.

## Viewing the models

Open `viewer/index.html` in a browser (served over http, not opened as a local file, so the models can load) to see all ten signs on an interactive turntable — drag to orbit, scroll to zoom. The gallery loads an HDR-style room environment and uses ACES filmic tone mapping so the gold, silver, brass and iron cut-outs reflect and gleam correctly. `viewer/single.html?id=city_tavern` shows one sign as a clean product shot; add `&yaw=0.45` for a 3/4 angle.
