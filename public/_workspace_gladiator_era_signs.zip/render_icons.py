import sys, os
from PIL import Image, ImageDraw
from signlib import EMBLEMS

def render(names, cell=460, cols=3, out="previews/icons_big.png", bg=(38,26,16)):
    rows = (len(names)+cols-1)//cols
    img = Image.new("RGB", (cell*cols, cell*rows), bg)
    d = ImageDraw.Draw(img)
    for i, n in enumerate(names):
        r, c = divmod(i, cols)
        cx = c*cell + cell/2
        cy = r*cell + cell/2
        EMBLEMS[n](d, cx, cy, cell*0.66, (230,196,110), 7)
        d.text((c*cell+10, r*cell+8), n, fill=(250,240,220))
    img.save(out)
    print("saved", out, img.size)

if __name__ == "__main__":
    names = sys.argv[1:] or list(EMBLEMS.keys())
    render(names)
