"""
emblems3d.py
- Draws each emblem as a SOLID silhouette (pictogram) into a binary mask.
- Converts a mask into an extruded 3D mesh (with holes + optional bevel).
Used to build physical metal/wood cutout emblems for the signs.
"""
import math
import os
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont
import trimesh
from shapely.geometry import Polygon
from shapely.ops import unary_union

S = 1024  # mask resolution

FONTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "fonts")

# ----------------------------------------------------------------------------
# drawing helpers (unit coords 0..1 -> pixels)
# ----------------------------------------------------------------------------
def _u(pts):
    return [(x * S, y * S) for (x, y) in pts]


def poly(d, pts, v=255):
    d.polygon(_u(pts), fill=v)


def ell(d, cx, cy, rx, ry, v=255):
    d.ellipse([(cx - rx) * S, (cy - ry) * S, (cx + rx) * S, (cy + ry) * S], fill=v)


def rrect(d, x0, y0, x1, y1, r, v=255):
    d.rounded_rectangle([x0 * S, y0 * S, x1 * S, y1 * S], radius=r * S, fill=v)


def tline(d, pts, w, v=255):
    d.line(_u(pts), fill=v, width=max(1, int(w * S)), joint="curve")


def tarc(d, cx, cy, rx, ry, a0, a1, w, v=255):
    d.arc([(cx - rx) * S, (cy - ry) * S, (cx + rx) * S, (cy + ry) * S],
          a0, a1, fill=v, width=max(1, int(w * S)))


def rot_rect(px, py, w, h, ang):
    a = math.radians(ang)
    c, s = math.cos(a), math.sin(a)
    out = []
    for (dx, dy) in [(-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)]:
        out.append((px + dx * c - dy * s, py + dx * s + dy * c))
    return out


def star(d, cx, cy, r, v=255, inner=0.40):
    pts = []
    for i in range(8):
        a = math.radians(i * 45 - 90)
        rr = r if i % 2 == 0 else r * inner
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    poly(d, pts, v)


def leaf_ell(d, x, y, ang, L, W, v=255):
    pts = []
    for t in range(0, 360, 12):
        a = math.radians(t)
        lx = (L / 2) * math.cos(a)
        ly = (W / 2) * math.sin(a)
        pts.append((x + lx * math.cos(ang) - ly * math.sin(ang),
                    y + lx * math.sin(ang) + ly * math.cos(ang)))
    poly(d, pts, v)


def laurel_ring(d, cx, cy, r, n, a0, a1, leafL, leafW, v=255, mirror=True):
    angs = np.linspace(a0, a1, n)
    branches = [angs] + ([180 - angs] if mirror else [])
    for base in branches:
        for a in base:
            ar = math.radians(a)
            x = cx + r * math.cos(ar)
            y = cy - r * math.sin(ar)
            leaf_ell(d, x, y, ar + math.pi / 2, leafL, leafW, v)


def quill(d, cx, cy, ang, v=255):
    a = math.radians(ang)
    # shaft
    p0 = (cx - 0.10 * math.cos(a), cy - 0.10 * math.sin(a))
    p1 = (cx + 0.16 * math.cos(a), cy + 0.16 * math.sin(a))
    tline(d, [p0, p1], 0.016, v)
    # feather
    leaf_ell(d, cx + 0.06 * math.cos(a), cy + 0.06 * math.sin(a), a, 0.30, 0.11, v)


def draw_sword(d, cx, cy, ang, scale=1.0, v=255):
    a = math.radians(ang)
    c, s = math.cos(a), math.sin(a)

    def T(px, py):
        px, py = px * scale, py * scale
        return (cx + px * c - py * s, cy + px * s + py * c)

    # blade (elongated diamond)
    poly(d, [T(0, -0.42), T(0.045, -0.30), T(0.045, 0.10), T(-0.045, 0.10), T(-0.045, -0.30)], v)
    # guard
    poly(d, [T(-0.16, 0.10), T(0.16, 0.10), T(0.16, 0.17), T(-0.16, 0.17)], v)
    # grip
    poly(d, [T(-0.035, 0.17), T(0.035, 0.17), T(0.035, 0.34), T(-0.035, 0.34)], v)
    # pommel
    px, py = T(0, 0.38)
    ell(d, px, py, 0.055 * scale, 0.055 * scale, v)


def amphora(d, cx, cy, rx, ry, v=255):
    ell(d, cx, cy, rx, ry, v)
    poly(d, [(cx - rx * 0.35, cy - ry * 0.9), (cx + rx * 0.35, cy - ry * 0.9),
             (cx + rx * 0.28, cy - ry * 1.5), (cx - rx * 0.28, cy - ry * 1.5)], v)
    ell(d, cx, cy - ry * 1.5, rx * 0.34, ry * 0.14, v)
    # handles
    tarc(d, cx - rx * 1.05, cy - ry * 0.55, rx * 0.45, ry * 0.55, 90, 250, rx * 0.22, v)
    tarc(d, cx + rx * 1.05, cy - ry * 0.55, rx * 0.45, ry * 0.55, -70, 90, rx * 0.22, v)


# ----------------------------------------------------------------------------
# emblems  (solid silhouettes)
# ----------------------------------------------------------------------------
def e_colosseum(d):
    laurel_ring(d, 0.5, 0.30, 0.30, 7, 150, 30, 0.12, 0.052, mirror=False)
    rrect(d, 0.10, 0.30, 0.90, 0.88, 0.03, 255)
    rrect(d, 0.05, 0.88, 0.95, 0.95, 0.02, 255)
    rows = [(0.36, 0.50, 5), (0.54, 0.68, 6), (0.72, 0.86, 6)]
    for (y0, y1, n) in rows:
        for i in range(n):
            cx = 0.10 + 0.80 * (i + 0.5) / n
            w = (0.80 / n) * 0.52
            d.rounded_rectangle([(cx - w / 2) * S, y0 * S, (cx + w / 2) * S, y1 * S],
                                radius=(w / 2) * S, fill=0)
            d.rectangle([(cx - w / 2) * S, ((y0 + y1) / 2) * S, (cx + w / 2) * S, y1 * S], fill=0)


def e_helmet(d):
    for sgn in (-1, 1):
        tline(d, [(0.5 - sgn * 0.34, 0.94), (0.5 + sgn * 0.30, 0.12)], 0.035, 255)
        hx, hy = 0.5 + sgn * 0.30, 0.12
        poly(d, [(hx, hy), (hx - sgn * 0.07, hy + 0.12), (hx + sgn * 0.07, hy + 0.12)], 255)
    d.pieslice([0.26 * S, 0.28 * S, 0.74 * S, 0.72 * S], 180, 360, fill=255)
    rrect(d, 0.26, 0.48, 0.74, 0.58, 0.01, 255)
    poly(d, [(0.26, 0.54), (0.40, 0.54), (0.40, 0.80), (0.30, 0.80)], 255)
    poly(d, [(0.74, 0.54), (0.60, 0.54), (0.60, 0.80), (0.70, 0.80)], 255)
    tarc(d, 0.5, 0.40, 0.24, 0.28, 200, 340, 0.09, 255)
    d.rectangle([0.47 * S, 0.58 * S, 0.53 * S, 0.82 * S], fill=0)
    d.rectangle([0.42 * S, 0.58 * S, 0.58 * S, 0.63 * S], fill=0)


def e_caduceus(d):
    rrect(d, 0.47, 0.12, 0.53, 0.90, 0.03, 255)
    ell(d, 0.5, 0.11, 0.06, 0.06, 255)
    for sgn in (-1, 1):
        poly(d, [(0.50, 0.20), (0.50 + sgn * 0.10, 0.16), (0.50 + sgn * 0.22, 0.15),
                 (0.50 + sgn * 0.34, 0.19), (0.50 + sgn * 0.30, 0.25),
                 (0.50 + sgn * 0.18, 0.25), (0.50 + sgn * 0.10, 0.28), (0.50, 0.27)], 255)
        for k in range(2):
            x = 0.50 + sgn * (0.16 + 0.09 * k)
            d.line([(x * S, 0.185 * S), (x * S, 0.255 * S)], fill=0, width=int(0.012 * S))
    ys = np.linspace(0.26, 0.88, 60)
    xs = [0.5 + math.sin((y - 0.26) / 0.62 * math.pi * 2.4) * 0.11 for y in ys]
    tline(d, list(zip(xs, ys)), 0.045, 255)
    ell(d, xs[0], ys[0], 0.05, 0.045, 255)


def _mug(d, cx, cy, w, h, ang, flip=1, v=255):
    a = math.radians(ang)
    c, s = math.cos(a), math.sin(a)

    def T(px, py):
        return ((cx + px * c - py * s) * S, (cy + px * s + py * c) * S)

    bt, bb = w * 0.46, w * 0.40
    tp, bp = -h * 0.5, h * 0.5
    d.polygon([T(-bt, tp), T(bt, tp), T(bb, bp), T(-bb, bp)], fill=v)
    # handle bulging outward on the 'flip' side
    pts = [T(flip * w * (0.40 + 0.34 * math.cos(math.radians(t))),
             h * 0.30 * math.sin(math.radians(t)))
           for t in np.linspace(-80, 80, 16)]
    d.line(pts, fill=v, width=int(w * 0.16 * S), joint="curve")
    for i in range(3):
        fx = -w * 0.26 + i * w * 0.26
        ccx, ccy = T(fx, tp)
        r = w * 0.15 * S
        d.ellipse([ccx - r, ccy - r, ccx + r, ccy + r], fill=v)


def e_mugs(d):
    _mug(d, 0.29, 0.60, 0.30, 0.46, 22, flip=-1)
    _mug(d, 0.71, 0.60, 0.30, 0.46, -22, flip=1)
    star(d, 0.5, 0.27, 0.09, 255)


def e_swords_laurel(d):
    laurel_ring(d, 0.5, 0.5, 0.36, 9, 250, 110, 0.15, 0.055, 255)
    draw_sword(d, 0.5, 0.5, 46)
    draw_sword(d, 0.5, 0.5, -46)
    ell(d, 0.5, 0.5, 0.075, 0.075, 255)


def e_scroll_seal(d):
    rrect(d, 0.20, 0.18, 0.64, 0.82, 0.04, 255)
    for (ex, ey) in [(0.20, 0.22), (0.64, 0.22), (0.20, 0.78), (0.64, 0.78)]:
        ell(d, ex, ey, 0.06, 0.06, 255)
    for i in range(4):
        y = 0.30 + i * 0.115
        d.rectangle([0.27 * S, y * S, 0.57 * S, (y + 0.045) * S], fill=0)
    ell(d, 0.72, 0.72, 0.10, 0.10, 255)
    poly(d, [(0.66, 0.78), (0.72, 0.78), (0.68, 0.94)], 255)
    poly(d, [(0.78, 0.78), (0.72, 0.78), (0.76, 0.94)], 255)
    quill(d, 0.74, 0.22, -32)


def e_forge(d):
    poly(d, [(0.20, 0.62), (0.15, 0.66), (0.20, 0.70), (0.62, 0.70), (0.62, 0.76),
             (0.54, 0.76), (0.54, 0.88), (0.66, 0.88), (0.66, 0.94), (0.30, 0.94),
             (0.30, 0.88), (0.38, 0.88), (0.38, 0.76), (0.20, 0.76)], 255)
    tline(d, [(0.24, 0.68), (0.66, 0.68)], 0.045, 255)
    tline(d, [(0.12, 0.86), (0.24, 0.70)], 0.035, 255)
    tline(d, [(0.12, 0.86), (0.22, 0.74)], 0.035, 255)
    tline(d, [(0.88, 0.18), (0.68, 0.50)], 0.05, 255)
    poly(d, rot_rect(0.66, 0.54, 0.20, 0.11, -50), 255)
    for (sx, sy) in [(0.72, 0.58), (0.78, 0.52), (0.74, 0.45), (0.67, 0.42), (0.82, 0.60)]:
        star(d, sx, sy, 0.035, 255)


def e_sack(d):
    # money bag (larger, central)
    poly(d, [(0.44, 0.26), (0.32, 0.36), (0.26, 0.52), (0.32, 0.70), (0.44, 0.80),
             (0.56, 0.80), (0.68, 0.70), (0.74, 0.52), (0.68, 0.36), (0.56, 0.26)], 255)
    rrect(d, 0.42, 0.20, 0.58, 0.27, 0.02, 255)
    poly(d, [(0.44, 0.21), (0.41, 0.10), (0.49, 0.13)], 255)
    poly(d, [(0.56, 0.21), (0.59, 0.10), (0.51, 0.13)], 255)
    for (cx, cy) in [(0.46, 0.10), (0.55, 0.07), (0.63, 0.13), (0.50, 0.03)]:
        ell(d, cx, cy, 0.045, 0.045, 255)
    # amphora (smaller, left)
    amphora(d, 0.13, 0.60, 0.075, 0.14)
    # basket (smaller, right)
    poly(d, [(0.82, 0.52), (0.96, 0.52), (0.93, 0.72), (0.85, 0.72)], 255)
    for i in range(2):
        y = 0.58 + i * 0.08
        d.line([(0.825 * S, y * S), (0.955 * S, y * S)], fill=0, width=int(0.012 * S))


def e_book_scroll(d):
    # scroll behind (top)
    rrect(d, 0.26, 0.12, 0.74, 0.23, 0.05, 255)
    ell(d, 0.26, 0.175, 0.05, 0.055, 255)
    ell(d, 0.74, 0.175, 0.05, 0.055, 255)
    # open book (two pages + spine)
    poly(d, [(0.50, 0.36), (0.16, 0.30), (0.16, 0.70), (0.50, 0.78)], 255)
    poly(d, [(0.50, 0.36), (0.84, 0.30), (0.84, 0.70), (0.50, 0.78)], 255)
    poly(d, [(0.465, 0.355), (0.535, 0.355), (0.535, 0.785), (0.465, 0.785)], 255)
    # page line holes
    for i in range(3):
        y = 0.44 + i * 0.09
        d.line([(0.22 * S, y * S), (0.45 * S, (y - 0.02) * S)], fill=0, width=int(0.012 * S))
        d.line([(0.55 * S, (y - 0.02) * S), (0.78 * S, y * S)], fill=0, width=int(0.012 * S))
    # bookmark ribbon (signals 'book')
    poly(d, [(0.465, 0.78), (0.535, 0.78), (0.515, 0.94), (0.485, 0.94)], 255)
    poly(d, [(0.485, 0.94), (0.515, 0.94), (0.50, 0.99)], 255)
    # quill
    quill(d, 0.85, 0.27, -35)


def e_shield_swords(d):
    laurel_ring(d, 0.5, 0.5, 0.38, 8, 250, 110, 0.14, 0.05, 255)
    draw_sword(d, 0.5, 0.5, 50, scale=0.92)
    draw_sword(d, 0.5, 0.5, -50, scale=0.92)
    poly(d, [(0.34, 0.34), (0.5, 0.28), (0.66, 0.34), (0.66, 0.56), (0.5, 0.78), (0.34, 0.56)], 255)
    ell(d, 0.5, 0.50, 0.065, 0.065, 0)


EMBLEM_DRAW = {
    "colosseum": e_colosseum,
    "helmet": e_helmet,
    "caduceus": e_caduceus,
    "mugs": e_mugs,
    "swords_laurel": e_swords_laurel,
    "scroll_seal": e_scroll_seal,
    "forge": e_forge,
    "sack": e_sack,
    "book_scroll": e_book_scroll,
    "shield_swords": e_shield_swords,
}


def make_mask(name, size=S):
    img = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(img)
    global S
    old = S
    S = size
    EMBLEM_DRAW[name](d)
    S = old
    return img


# ----------------------------------------------------------------------------
# mask -> extruded mesh
# ----------------------------------------------------------------------------
def _contours_to_polygons(mask_img, simplify=1.6, min_area=40):
    arr = np.array(mask_img)
    _, bw = cv2.threshold(arr, 127, 255, cv2.THRESH_BINARY)
    cnts, hier = cv2.findContours(bw, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    if hier is None:
        return []
    hier = hier[0]
    H, W = arr.shape
    polys = []
    for i, c in enumerate(cnts):
        if hier[i][3] != -1:
            continue  # only top-level here
        if cv2.contourArea(c) < min_area:
            continue
        ext = cv2.approxPolyDP(c, simplify, True).reshape(-1, 2)
        if len(ext) < 3:
            continue
        # pixel -> model (y up), centred
        def conv(pts):
            return [((x - W / 2) / H, (H / 2 - y) / H) for (x, y) in pts]
        shell = conv(ext)
        holes = []
        child = hier[i][2]
        while child != -1:
            if cv2.contourArea(cnts[child]) >= min_area:
                h = cv2.approxPolyDP(cnts[child], simplify, True).reshape(-1, 2)
                if len(h) >= 3:
                    holes.append(conv(h))
            child = hier[child][0]
        try:
            p = Polygon(shell, holes)
            if not p.is_valid:
                p = p.buffer(0)
            if p.is_empty:
                continue
            if p.geom_type == "MultiPolygon":
                polys.extend(list(p.geoms))
            else:
                polys.append(p)
        except Exception:
            pass
    return polys


def _text_mask(lines, px, weight="Bold", tracking_ratio=0.05, pad=34,
               font_file="Cinzel.ttf"):
    """Render one or more text lines to an 'L' mask, tightly cropped."""
    font = ImageFont.truetype(os.path.join(FONTS, font_file), px)
    if weight:
        try:
            font.set_variation_by_name(weight)
        except Exception:
            pass
    dummy = ImageDraw.Draw(Image.new("L", (8, 8)))
    tr = px * tracking_ratio
    widths, heights = [], []
    for ln in lines:
        w = 0
        for ch in ln:
            b = dummy.textbbox((0, 0), ch, font=font)
            w += (b[2] - b[0]) + tr
        if ln:
            w -= tr
        asc, desc = font.getmetrics()
        widths.append(w)
        heights.append(asc + desc)
    gap = int(px * 0.24)
    W = int(max(widths)) + 2 * pad
    H = int(sum(heights) + gap * (len(lines) - 1)) + 2 * pad
    img = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(img)
    y = pad
    for ln, w, h in zip(lines, widths, heights):
        x = pad + (max(widths) - w) / 2
        for ch in ln:
            b = d.textbbox((0, 0), ch, font=font)
            d.text((x - b[0], y), ch, font=font, fill=255)
            x += (b[2] - b[0]) + tr
        y += h + gap
    return img


def make_sign_mask(icon, lines, W=1024, H=1280, weight="Bold", ring=True):
    """Compose a single cut-out sign silhouette: hanging ring + emblem + name.

    Returns an 'L' mask where white = solid metal.  The whole thing is later
    extruded as ONE piece, so the emblem *is* the sign.
    """
    canvas = Image.new("L", (W, H), 0)

    # --- emblem, scaled to fill the upper band, cropped to its content ---
    icon_box_h = int(H * 0.55)
    icon_box_w = int(W * 0.94)
    m = make_mask(icon, 1024)
    arr = np.array(m)
    ys, xs = np.where(arr > 0)
    if len(xs):
        m = m.crop((int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1))
    iw, ih = m.size
    sc = min(icon_box_w / iw, icon_box_h / ih)
    m = m.resize((max(1, int(iw * sc)), max(1, int(ih * sc))), Image.LANCZOS)
    ix = (W - m.size[0]) // 2
    iy = int(H * 0.135)
    canvas.paste(m, (ix, iy), m)

    # --- name text ---
    tm = _text_mask(lines, px=int(H * 0.074), weight=weight)
    tw, th = tm.size
    max_tw = int(W * 0.92)
    if tw > max_tw:
        s2 = max_tw / tw
        tm = tm.resize((max(1, int(tw * s2)), max(1, int(th * s2))), Image.LANCZOS)
    tx = (W - tm.size[0]) // 2
    ty = H - tm.size[1] - int(H * 0.03)
    canvas.paste(tm, (tx, ty), tm)

    d = ImageDraw.Draw(canvas)
    cx = W // 2
    carr = np.array(canvas)
    stem_w = max(8, int(W * 0.014))

    # --- stem: emblem bottom -> text top (anchored at the lowest solid pixel) ---
    col = carr[:, cx]
    filled = np.where(col > 0)[0]
    icon_low = int(filled.max()) if len(filled) else iy + m.size[1]
    y0 = icon_low - int(H * 0.02)
    y1 = ty + int(H * 0.012)
    if y1 < y0:
        y1 = y0 + 2
    d.rectangle([cx - stem_w // 2, y0, cx + stem_w // 2, y1], fill=255)

    # --- hanging ring at the top, joined to the emblem by a short neck ---
    if ring:
        r_out = int(W * 0.043)
        r_in = int(W * 0.023)
        cyr = int(H * 0.052)
        d.ellipse([cx - r_out, cyr - r_out, cx + r_out, cyr + r_out], fill=255)
        d.ellipse([cx - r_in, cyr - r_in, cx + r_in, cyr + r_in], fill=0)
        # neck from ring down into the emblem's highest solid pixel
        col2 = np.array(canvas)[:, cx]
        filled2 = np.where(col2 > 0)[0]
        filled2 = filled2[filled2 > cyr]  # ignore the ring itself
        icon_top = int(filled2.min()) if len(filled2) else iy
        ny0 = cyr + r_out - 4
        ny1 = icon_top + int(H * 0.01)
        if ny1 < ny0:
            ny1 = ny0 + 2
        d.rectangle([cx - stem_w // 2, ny0, cx + stem_w // 2, ny1], fill=255)
    return canvas


def mask_img_to_mesh(mask, target_h=1.3, thickness=0.05, bevel=0.006,
                     metal_color=(1.0, 0.78, 0.35), metal=1.0, rough=0.3,
                     base_color=None, simplify=1.2, min_area=18):
    """Extrude an arbitrary mask image into a watertight cut-out mesh."""
    polys = _contours_to_polygons(mask, simplify=simplify, min_area=min_area)
    if not polys:
        return None
    parts = []
    for p in polys:
        try:
            m = trimesh.creation.extrude_polygon(p, height=thickness)
            parts.append(m)
        except Exception:
            pass
    if not parts:
        return None
    base = trimesh.util.concatenate(parts)
    # scale so total height == target_h (mask is square, shape within)
    ext = base.extents
    sc = target_h / ext[1] if ext[1] > 0 else 1.0
    base.apply_scale(sc)
    base.apply_translation([-base.bounds[0][0] - base.extents[0] / 2, 0, 0])
    base.apply_translation([0, -base.bounds[0][1], 0])
    # recentre x/y around origin
    base.apply_translation([-(base.bounds[0][0] + base.bounds[1][0]) / 2,
                            -(base.bounds[0][1] + base.bounds[1][1]) / 2, 0])

    bc = base_color or metal_color
    mat = trimesh.visual.material.PBRMaterial(
        baseColorFactor=[bc[0], bc[1], bc[2], 1.0],
        metallicFactor=metal, roughnessFactor=rough)
    base.visual = trimesh.visual.TextureVisuals(material=mat)
    return base


def mask_to_mesh(name, target_h=0.9, thickness=0.06, bevel=0.006,
                 metal_color=(1.0, 0.78, 0.35), metal=1.0, rough=0.3,
                 base_color=None, mask_size=S):
    """Back-compat wrapper: build an emblem mask then extrude it."""
    return mask_img_to_mesh(make_mask(name, mask_size), target_h=target_h,
                            thickness=thickness, bevel=bevel,
                            metal_color=metal_color, metal=metal, rough=rough,
                            base_color=base_color)


def sign_mask_to_mesh(icon, lines, target_h=1.3, thickness=0.05,
                      metal_color=(1.0, 0.78, 0.35), metal=1.0, rough=0.3,
                      W=1024, H=1280, weight="Bold", ring=True):
    """Build the composite cut-out sign mask and extrude it to one mesh."""
    mask = make_sign_mask(icon, lines, W=W, H=H, weight=weight, ring=ring)
    return mask_img_to_mesh(mask, target_h=target_h, thickness=thickness,
                            metal_color=metal_color, metal=metal, rough=rough)


if __name__ == "__main__":
    import os
    os.makedirs("previews", exist_ok=True)
    names = list(EMBLEM_DRAW.keys())
    cell = 300
    cols, rows = 5, 2
    img = Image.new("RGB", (cell * cols, cell * rows), (30, 22, 14))
    for i, n in enumerate(names):
        r, c = divmod(i, cols)
        m = make_mask(n, 300)
        arr = np.array(m).astype(np.float32) / 255.0
        col = np.array([230, 190, 100], np.float32)
        out = (arr[..., None] * col).astype(np.uint8)
        img.paste(Image.fromarray(out), (c * cell, r * cell))
    img.save("previews/masks_sheet.png")
    print("saved previews/masks_sheet.png")
