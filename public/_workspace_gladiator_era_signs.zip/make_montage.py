#!/usr/bin/env python3
"""Build a 5x2 contact-sheet montage of all ten sign previews."""
import os
from PIL import Image, ImageDraw, ImageFont

PREV = "previews"
FONT_DIR = "assets/fonts"

SIGNS = [
    ("grand_colosseum",    "GRAND COLOSSEUM",        "Gold cut-out"),
    ("gladiator_barracks", "GLADIATOR BARRACKS",     "Iron cut-out"),
    ("arena_medical",      "ARENA MEDICAL HOUSE",    "Silver cut-out"),
    ("city_tavern",        "CITY TAVERN",            "Brass cut-out"),
    ("veteran_hall",       "VETERAN GLADIATOR HALL", "Gold cut-out"),
    ("gladiator_academy",  "GLADIATOR ACADEMY",      "Brass cut-out"),
    ("smithing_forge",     "SMITHING FORGE",         "Iron cut-out"),
    ("general_store",      "GENERAL STORE",          "Brass cut-out"),
    ("records_library",    "RECORDS LIBRARY",        "Gold cut-out"),
    ("training_hall",      "TRAINING HALL",          "Silver cut-out"),
]

COLS, ROWS = 5, 2
CELL_W = 600
GAP = 26
PAD = 40
TITLE_H = 150
LABEL_H = 78

# cell image height from first preview aspect
im0 = Image.open(os.path.join(PREV, SIGNS[0][0] + ".png"))
CELL_H = int(CELL_W * im0.size[1] / im0.size[0])

W = PAD * 2 + COLS * CELL_W + (COLS - 1) * GAP
H = PAD + TITLE_H + ROWS * (CELL_H + LABEL_H) + (ROWS - 1) * GAP + PAD

canvas = Image.new("RGB", (W, H), (14, 11, 8))
d = ImageDraw.Draw(canvas)

# subtle radial vignette background
import math
for y in range(H):
    pass  # keep flat dark for speed

def font(path, size, index=0):
    try:
        f = ImageFont.truetype(path, size)
        try:
            f.set_variation_by_name(index) if False else None
        except Exception:
            pass
        return f
    except Exception:
        return ImageFont.load_default()

title_font = font(os.path.join(FONT_DIR, "CinzelDecorative.ttf"), 60)
sub_font   = font(os.path.join(FONT_DIR, "Cinzel.ttf"), 26)
lab_font   = font(os.path.join(FONT_DIR, "Cinzel.ttf"), 24)
mat_font   = font(os.path.join(FONT_DIR, "Cinzel.ttf"), 19)

GOLD = (212, 175, 55)
CREAM = (232, 220, 196)
DIM = (168, 150, 118)

# title
t = "GLADIATOR ERA  \u00b7  SHOP SIGNS"
tw = d.textlength(t, font=title_font)
d.text(((W - tw) / 2, PAD + 8), t, font=title_font, fill=GOLD)
s = "Ten hanging cut-out signs  \u00b7  the emblem itself is the sign"
sw = d.textlength(s, font=sub_font)
d.text(((W - sw) / 2, PAD + 88), s, font=sub_font, fill=DIM)

# gold rule under title
d.line([(W/2 - 420, PAD + TITLE_H - 14), (W/2 + 420, PAD + TITLE_H - 14)], fill=(90, 74, 40), width=2)

y0 = PAD + TITLE_H
for i, (sid, label, mat) in enumerate(SIGNS):
    r, c = divmod(i, COLS)
    x = PAD + c * (CELL_W + GAP)
    y = y0 + r * (CELL_H + LABEL_H + GAP)
    try:
        im = Image.open(os.path.join(PREV, sid + ".png")).convert("RGB")
    except Exception as e:
        print("missing", sid, e); continue
    im = im.resize((CELL_W, CELL_H), Image.LANCZOS)
    canvas.paste(im, (x, y))
    # thin gold frame
    d.rectangle([x, y, x + CELL_W - 1, y + CELL_H - 1], outline=(78, 64, 36), width=2)
    # label
    lw = d.textlength(label, font=lab_font)
    d.text((x + (CELL_W - lw) / 2, y + CELL_H + 12), label, font=lab_font, fill=CREAM)
    mw = d.textlength(mat, font=mat_font)
    d.text((x + (CELL_W - mw) / 2, y + CELL_H + 44), mat, font=mat_font, fill=GOLD)

canvas.save(os.path.join(PREV, "montage.png"))
print("saved previews/montage.png", canvas.size)
