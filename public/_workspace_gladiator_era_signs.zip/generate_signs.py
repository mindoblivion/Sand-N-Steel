"""
generate_signs.py
Builds 10 game-ready gladiator-era shop signs where the CUT-OUT EMBLEM *IS* THE
SIGN.  Each sign is a single extruded metal silhouette (emblem + name + hanging
ring) suspended by a chain from an iron bracket, so there is no board and no
painted panel -- the icon itself is the signage.

 - Materials: gold / silver / brass / iron metals on dark-iron bracket hardware.
 - Exports .glb (embedded PBR materials) and .obj/.mtl per sign + manifest.json.
"""
import os, json, math
import numpy as np
from PIL import Image
import trimesh
import emblems3d as E3

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "signs")

# ---- palette ---------------------------------------------------------------
METALS = {
    "gold":   dict(color=(1.00, 0.766, 0.336), rough=0.26),
    "silver": dict(color=(0.94, 0.94, 0.97), rough=0.20),
    "brass":  dict(color=(0.86, 0.68, 0.30), rough=0.34),
    "iron":   dict(color=(0.44, 0.46, 0.49), rough=0.46),
}
IRON = (0.20, 0.21, 0.23)          # bracket hardware
IRON_ROUGH = 0.55

# ---- the 10 signs ----------------------------------------------------------
SIGNS = [
    dict(id="grand_colosseum",    title="GRAND COLOSSEUM",       latin="COLOSSEVM MAGNVM",
         metal="gold",   icon="colosseum",      lines=["GRAND", "COLOSSEUM"]),
    dict(id="gladiator_barracks", title="GLADIATOR BARRACKS",    latin="CASTRA GLADIATORVM",
         metal="iron",   icon="helmet",         lines=["GLADIATOR", "BARRACKS"]),
    dict(id="arena_medical",      title="ARENA MEDICAL HOUSE",   latin="DOMVS MEDICA",
         metal="silver", icon="caduceus",       lines=["ARENA", "MEDICAL HOUSE"]),
    dict(id="city_tavern",        title="CITY TAVERN",           latin="TABERNA VRBANA",
         metal="brass",  icon="mugs",           lines=["CITY", "TAVERN"]),
    dict(id="veteran_hall",       title="VETERAN GLADIATOR HALL", latin="AVLA VETERANORVM",
         metal="gold",   icon="swords_laurel",  lines=["VETERAN", "GLADIATOR HALL"]),
    dict(id="gladiator_academy",  title="GLADIATOR ACADEMY",     latin="ACADEMIA GLADIATORIA",
         metal="brass",  icon="scroll_seal",    lines=["GLADIATOR", "ACADEMY"]),
    dict(id="smithing_forge",     title="SMITHING FORGE",        latin="FABRICA FERRI",
         metal="iron",   icon="forge",          lines=["SMITHING", "FORGE"]),
    dict(id="general_store",      title="GENERAL STORE",         latin="MERCATVS",
         metal="brass",  icon="sack",           lines=["GENERAL", "STORE"]),
    dict(id="records_library",    title="RECORDS LIBRARY",       latin="BIBLIOTHECA",
         metal="gold",   icon="book_scroll",    lines=["RECORDS", "LIBRARY"]),
    dict(id="training_hall",      title="TRAINING HALL",         latin="PALAESTRA",
         metal="silver", icon="shield_swords",  lines=["TRAINING", "HALL"]),
]


# ============================================================================
# small geometry helpers
# ============================================================================
def apply_mat(m, color, metal=1.0, rough=0.4):
    mat = trimesh.visual.material.PBRMaterial(
        baseColorFactor=[color[0], color[1], color[2], 1.0],
        metallicFactor=metal, roughnessFactor=rough)
    m.visual = trimesh.visual.TextureVisuals(material=mat)
    return m


def cyl(radius, height, center, color, metal=1.0, rough=0.4, sections=24, axis="y"):
    m = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    if axis == "y":
        m.apply_transform(trimesh.transformations.rotation_matrix(math.radians(90), [1, 0, 0]))
    elif axis == "x":
        m.apply_transform(trimesh.transformations.rotation_matrix(math.radians(90), [0, 1, 0]))
    m.apply_translation(center)
    apply_mat(m, color, metal, rough)
    return m


def cyl_between(p0, p1, radius, color, metal=1.0, rough=0.4, sections=18):
    p0 = np.array(p0, float); p1 = np.array(p1, float)
    v = p1 - p0
    h = float(np.linalg.norm(v))
    if h < 1e-6:
        return None
    m = trimesh.creation.cylinder(radius=radius, height=h, sections=sections)
    z = np.array([0.0, 0.0, 1.0])
    vv = v / h
    axis = np.cross(z, vv)
    if np.linalg.norm(axis) < 1e-6:
        R = np.eye(4) if vv[2] > 0 else trimesh.transformations.rotation_matrix(math.pi, [1, 0, 0])
    else:
        ang = math.acos(float(np.clip(np.dot(z, vv), -1, 1)))
        R = trimesh.transformations.rotation_matrix(ang, axis)
    m.apply_transform(R)
    m.apply_translation((p0 + p1) / 2)
    apply_mat(m, color, metal, rough)
    return m


def box(dims, center, color, metal=1.0, rough=0.4):
    m = trimesh.creation.box(extents=dims)
    m.apply_translation(center)
    apply_mat(m, color, metal, rough)
    return m


def export_obj_mtl(scene, obj_path, sign_name, sign_col, sign_rough):
    """Write an OBJ that keeps the node names + a small MTL (sign metal + iron)."""
    mtl_name = os.path.basename(obj_path)[:-4] + ".mtl"
    mtl_path = obj_path[:-4] + ".mtl"
    lines = ["# Gladiator-era cut-out sign", f"mtllib {mtl_name}"]
    v_off = 1
    for node in scene.graph.nodes_geometry:
        T, gname = scene.graph[node]
        geom = scene.geometry[gname]
        verts = trimesh.transformations.transform_points(geom.vertices, T)
        mat = sign_name if node == "sign" else "bracket_iron"
        lines.append(f"o {node}")
        lines.append(f"usemtl {mat}")
        for v in verts:
            lines.append(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}")
        for f in geom.faces:
            lines.append("f " + " ".join(str(v_off + int(i)) for i in f))
        v_off += len(verts)
    with open(obj_path, "w") as f:
        f.write("\n".join(lines) + "\n")

    def block(name, color, rough):
        kd = " ".join(f"{c:.6f}" for c in color)
        ks = " ".join(f"{c:.6f}" for c in color)
        ns = max(1.0, (1.0 - rough) * 250.0)
        return (f"newmtl {name}\nKa 0.10 0.10 0.10\nKd {kd}\nKs {ks}\n"
                f"Ns {ns:.1f}\nd 1.0\nillum 2\n")
    with open(mtl_path, "w") as f:
        f.write(block(sign_name, sign_col, sign_rough) + "\n")
        f.write(block("bracket_iron", IRON, IRON_ROUGH) + "\n")


def chain(x, y_top, y_bot, major=0.035, minor=0.011, color=IRON, rough=IRON_ROUGH):
    """A short vertical chain of alternating torus links."""
    n = max(2, int(round((y_top - y_bot) / (major * 1.35))))
    links = []
    for i in range(n):
        t = i / max(1, n - 1)
        y = y_top + (y_bot - y_top) * t
        link = trimesh.creation.torus(major_radius=major, minor_radius=minor,
                                      major_sections=18, minor_sections=9)
        if i % 2 == 0:
            link.apply_transform(trimesh.transformations.rotation_matrix(math.radians(90), [1, 0, 0]))
        else:
            link.apply_transform(trimesh.transformations.rotation_matrix(math.radians(90), [0, 1, 0]))
        link.apply_translation([x, y, 0])
        apply_mat(link, color, 1.0, rough)
        links.append(link)
    return links


# ============================================================================
# the hanging cut-out sign
# ============================================================================
def build_scene(cfg):
    metal = METALS[cfg["metal"]]
    mcol, mrough = metal["color"], metal["rough"]

    SIGN_H = 1.55          # height of the cut-out (emblem + name + ring)
    SIGN_T = 0.05          # metal thickness
    SIGN_TOP = 2.34        # world y of the very top of the sign (ring top)
    POST_X = -0.92
    POST_TOP = 2.72
    ARM_Y = 2.58

    scene = trimesh.Scene()

    # ---- the cut-out sign itself (emblem + name + ring, one mesh) ----
    sign = E3.sign_mask_to_mesh(cfg["icon"], cfg["lines"], target_h=SIGN_H,
                                thickness=SIGN_T, metal_color=mcol, metal=1.0,
                                rough=mrough, W=1024, H=1280, weight="Bold")
    if sign is None:
        raise RuntimeError("sign mesh failed for " + cfg["id"])
    # centre in z, then hang so its top sits at SIGN_TOP
    sign.apply_translation([0, 0, -SIGN_T / 2])
    sign.apply_translation([0, SIGN_TOP - sign.bounds[1][1], 0])
    scene.add_geometry(sign, node_name="sign")

    # ---- bracket: post + base + cap ----
    scene.add_geometry(cyl(0.075, POST_TOP - 0.10, (POST_X, (POST_TOP + 0.10) / 2, 0),
                           IRON, 1.0, IRON_ROUGH, 28), node_name="post")
    scene.add_geometry(cyl(0.20, 0.12, (POST_X, 0.06, 0), IRON, 1.0, IRON_ROUGH, 30),
                       node_name="post_base")
    cap = trimesh.creation.icosphere(subdivisions=2, radius=0.10)
    cap.apply_translation((POST_X, POST_TOP + 0.04, 0))
    apply_mat(cap, IRON, 1.0, IRON_ROUGH)
    scene.add_geometry(cap, node_name="post_cap")

    # ---- bracket: horizontal arm + diagonal brace ----
    arm_end_x = 0.22
    scene.add_geometry(cyl_between((POST_X, ARM_Y, 0), (arm_end_x, ARM_Y, 0), 0.05,
                                   IRON, 1.0, IRON_ROUGH, 20), node_name="arm")
    scene.add_geometry(cyl_between((POST_X, ARM_Y - 0.62, 0), (arm_end_x - 0.10, ARM_Y - 0.03, 0),
                                   0.032, IRON, 1.0, IRON_ROUGH, 16), node_name="brace")
    # small decorative scroll where the arm meets the post
    scroll = trimesh.creation.torus(major_radius=0.09, minor_radius=0.026,
                                    major_sections=20, minor_sections=10)
    scroll.apply_transform(trimesh.transformations.rotation_matrix(math.radians(90), [1, 0, 0]))
    scroll.apply_translation((POST_X + 0.10, ARM_Y - 0.02, 0))
    apply_mat(scroll, IRON, 1.0, IRON_ROUGH)
    scene.add_geometry(scroll, node_name="scroll")

    # ---- hanging chain from the arm down to the sign's ring ----
    ring_cy = SIGN_TOP - 0.078        # ring centre (matches make_sign_mask layout)
    for i, link in enumerate(chain(0.0, ARM_Y - 0.02, ring_cy + 0.03)):
        scene.add_geometry(link, node_name=f"chain_{i}")

    return scene


# ============================================================================
# main
# ============================================================================
def main():
    os.makedirs(OUT, exist_ok=True)
    manifest = []
    for cfg in SIGNS:
        d = os.path.join(OUT, cfg["id"])
        os.makedirs(d, exist_ok=True)

        scene = build_scene(cfg)

        glb_path = os.path.join(d, f"{cfg['id']}.glb")
        scene.export(glb_path)

        obj_path = os.path.join(d, f"{cfg['id']}.obj")
        try:
            export_obj_mtl(scene, obj_path, cfg["metal"], METALS[cfg["metal"]]["color"],
                           METALS[cfg["metal"]]["rough"])
        except Exception as e:
            print("  OBJ export issue:", e)

        tri = sum(len(g.faces) for g in scene.geometry.values())
        manifest.append(dict(id=cfg["id"], title=cfg["title"], latin=cfg["latin"],
                             metal=cfg["metal"], icon=cfg["icon"],
                             glb=f"{cfg['id']}/{cfg['id']}.glb",
                             obj=f"{cfg['id']}/{cfg['id']}.obj"))
        print(f"[ok] {cfg['id']:20s} {cfg['metal']:6s} tris {tri:6d}  "
              f"glb {os.path.getsize(glb_path)//1024} KB")

    with open(os.path.join(OUT, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    print("\nDone. %d cut-out signs." % len(SIGNS))


if __name__ == "__main__":
    main()
