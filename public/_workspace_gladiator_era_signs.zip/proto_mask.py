#!/usr/bin/env python3
"""Prototype: render composite cut-out sign masks (icon + name + ring)."""
import numpy as np
from PIL import Image, ImageDraw
import emblems3d as E3

SIGNS = [
    ("colosseum", ["GRAND", "COLOSSEUM"]),
    ("helmet", ["GLADIATOR", "BARRACKS"]),
    ("caduceus", ["ARENA", "MEDICAL HOUSE"]),
    ("mugs", ["CITY", "TAVERN"]),
    ("swords_laurel", ["VETERAN", "GLADIATOR HALL"]),
    ("scroll_seal", ["GLADIATOR", "ACADEMY"]),
    ("forge", ["SMITHING", "FORGE"]),
    ("sack", ["GENERAL", "STORE"]),
    ("book_scroll", ["RECORDS", "LIBRARY"]),
    ("shield_swords", ["TRAINING", "HALL"]),
]

W, H = 1024, 1280
cols, rows = 5, 2
cw = 300
ch = int(cw * H / W)
img = Image.new("RGB", (cw * cols, ch * rows), (18, 14, 10))
for i, (icon, lines) in enumerate(SIGNS):
    r, c = divmod(i, cols)
    m = E3.make_sign_mask(icon, lines, W=W, H=H)
    arr = np.array(m).astype(np.float32) / 255.0
    col = np.array([232, 190, 100], np.float32)
    out = (arr[..., None] * col).astype(np.uint8)
    tile = Image.fromarray(out).resize((cw, ch), Image.LANCZOS)
    img.paste(tile, (c * cw, r * ch))
img.save("previews/cutout_masks.png")
print("saved previews/cutout_masks.png", img.size)
